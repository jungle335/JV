package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws Exception{

        String spatiu = "                            ";
        Scanner sc = new Scanner(System.in);
        Biblioteca b = new Biblioteca();

        while (true){;
            System.out.println("1 ----> adaugare in fisier");
            System.out.println("2 ----> afisare autori");
            System.out.println("3 ----> afisare autor");
            System.out.println("4 ----> afisare carti");
            System.out.println("5 ----> interfata grafica");
            System.out.println("6 ----> oprire program");
            int op = sc.nextInt();

            switch (op) {
                case 1: {
                    b.addAutor(new Autor("Mihai", "Eminescu", "Romania"));
                    b.addAutor(new Autor("Mihail", "Drumes", "Romania"));
                    b.addAutor(new Autor("Karl", "May", "Germania"));
                    b.addAutor(new Autor("Ernest", "Hemingway", "Anglia"));
                    b.addAutor(new Autor("Hermann", "Hesse", "Germania"));
                    b.addAutor(new Autor("Mihail", "Sadoveanu", "Romania"));
                    b.addAutor(new Autor("Jack", "London", "S.U.A."));
                    b.addAutor(new Autor("John", "Buchan", "Anglia"));

                    b.addCarte(new Carte("Invitatie la vals", 2, 1, "Fictiune", 1936, 15));
                    b.addCarte(new Carte("Cazul Magheru", 2, 2, "Fictiune", 1930, 12));
                    b.addCarte(new Carte("Batranul si marea", 4, 3, "Fictiune", 1952, 5));
                    b.addCarte(new Carte("Old Surehand", 3, 3, "Aventura", 1965, 7));
                    b.addCarte(new Carte("Lupul de stepa", 5, 4, "Filosofie", 1927, 3));
                    b.addCarte(new Carte("Fiesta", 4, 3, "Beletristica", 1926, 2));
                    b.addCarte(new Carte("Lupul de mare", 7, 4, "Aventura", 1904, 3));
                    b.addCarte(new Carte("Colt alb", 7, 4, "Fictiune", 1906, 3));
                    b.addCarte(new Carte("Mantia verde", 8, 3, "Fictiune", 1916, 2));
                    break;
                }
                case 2: {
                    String[][] autori = b.getAutori();
                    for (String[] a : autori) {
                        for (String aa : a) {
                            System.out.print(aa + " ");
                        }
                        System.out.println();
                    }
                    break;
                }

                case 3:{
                    System.out.println("Introduceti id-ul autorului");
                    int idA = sc.nextInt();
                    System.out.println(b.getInfoAutor(idA));
                    break;
                }

                case 4: {
                    String[][] carti = b.getCarti();
                    for (String[] c : carti) {
                        for (String cc : c) {
                            System.out.print(cc + spatiu.substring(0, spatiu.length() - cc.length()));
                        }
                        System.out.println();
                    }
                    break;
                }

                case 5: {
                    new CreeareCont();
                    Loguri.init("logs.csv");
                    break;
                }

                case 6:
                    System.exit(0);
            }

        }
    }
}