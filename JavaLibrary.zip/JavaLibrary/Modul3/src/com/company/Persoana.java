package com.company;

public abstract class Persoana {
    String pseudonim, nume, prenume;

    Persoana(){}

    public Persoana(String nume, String prenume){
        this.nume = nume;
        this.prenume = prenume;
    }

    public Persoana(String pseudonim, String nume, String prenume) {
        this.pseudonim = pseudonim;
        this.nume = nume;
        this.prenume = prenume;
    }

    public String getNume() { return nume; }
    public String getPrenume() { return prenume; }
    public String getPseudonim() { return pseudonim; }

    public void setNume(String nume) { this.nume = nume; }
    public void setPrenume(String prenume) { this.prenume = prenume; }

    @Override
    public String toString() {
        return nume + " " + prenume;
    }
}
