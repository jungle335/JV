package com.company;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws Exception{
        Biblioteca b = new Biblioteca();
        Scanner sc = new Scanner(System.in);
        String spatiu = "                            ";

        while (true){
            System.out.println("1 -----> interfata grafica");
            System.out.println("2 -----> afisare autori");
            System.out.println("3 -----> adaugare autor");
            System.out.println("4 -----> modificare autor");
            System.out.println("5 -----> stergere autor");
            System.out.println("6 -----> afisare edituri");
            System.out.println("7 ----> adaugare editura");
            System.out.println("8 -----> modificare editura");
            System.out.println("9 -----> stergere editura");
            System.out.println("10 -----> afisare carti");
            System.out.println("11 -----> adaugare carte");
            System.out.println("12 -----> modificare carte");
            System.out.println("13 -----> sterge carte");
            System.out.println("14 -----> inchidere meniu");

            int op = sc.nextInt();
            switch (op){
                case 1:
                    new CreeareCont();
                    Loguri.init("logs.csv");
                    break;

                case 2:
                    System.out.println("Autorii sunt: ");
                    String[][] autori = b.getAutori();
                    for (String[] s : autori){
                        for(String s1 : s){
                            System.out.print(s1 + spatiu.substring(0, spatiu.length() - s1.length()));
                        }
                        System.out.println();
                    }
                    break;

                case 3:
                    System.out.println("Nume autor:");
                    String nume = sc.next();
                    System.out.println("Prenume autor:");
                    String prenume = sc.next();
                    System.out.println("Tara autor:");
                    String tara = sc.next();
                    b.addAutor(new Autor(nume, prenume, tara));
                    break;

                case 4:
                    System.out.println("Id autor");
                    int id = sc.nextInt();
                    System.out.println("Camp pentru modificare autor:");
                    String camp = sc.next();
                    System.out.println("Valoarea pentru modificare autor:");
                    String val = sc.next();
                    b.modificaAutor(id, camp, val);
                    break;

                case 5:
                    System.out.println("Id autor");
                    b.deleteAutor(sc.nextInt());
                    break;

                case 6:
                    System.out.println("\nEditurile sunt: " + b.getEdituri());
                    break;

                case 7:
                    System.out.println("Denumire editura:");
                    b.addEdituri(new Editura(sc.next()));
                    break;

                case 8:
                    System.out.println("Id editura:");
                    int idEd = sc.nextInt();
                    System.out.println("Denumire noua:");
                    String denum = sc.next();
                    b.modificaEditura(idEd, denum);
                    break;

                case 9:
                    b.deleteEditura(sc.nextInt());
                    break;

                case 10:
                    System.out.println("Cartile sunt: ");
                    String[][] carti = b.getCarti();
                    for (String[] c : carti){
                        for(String c1 : c){
                            System.out.print(c1 + spatiu.substring(0, spatiu.length() - c1.length()));
                        }
                        System.out.println();
                    }
                    break;

                case 11:
                    System.out.println("Titlu:");
                    sc.nextLine();
                    String titlu = sc.nextLine();
                    System.out.println("Id autor:");
                    int idA = sc.nextInt();
                    System.out.println("Id Editura:");
                    int ide = sc.nextInt();
                    System.out.println("Categorie:");
                    String den = sc.next();
                    System.out.println("An Publicare:");
                    int anp = sc.nextInt();
                    System.out.println("Cantitate:");
                    int cant = sc.nextInt();
                    b.addCarte(new Carte(titlu, idA, ide, den, anp, cant));
                    break;

                case 12:
                    System.out.println("Id carte:");
                    int idC = sc.nextInt();
                    System.out.println("Camp pentru modificare:");
                    String f = sc.next();
                    System.out.println("Valoare noua:");
                    String x = sc.next();
                    b.modificaCarte(idC, f, String.valueOf(x));
                    break;

                case 13:
                    b.deleteCarte(sc.nextInt());
                    break;

                case 14:
                    System.exit(0);
                    break;
            }
        }

//        b.addAutor(new Autor("Mihai", "Eminescu", "Romania"));
//        b.addAutor(new Autor("Mihail", "Drumes", "Romania"));
//        b.addAutor(new Autor("Karl", "May", "Germania"));
//        b.addAutor(new Autor("Ernest", "Hemingway", "Anglia"));
//        b.addAutor(new Autor("Hermann", "Hesse", "Germania"));
//        b.addAutor(new Autor("Mihail", "Sadoveanu", "Romania"));
//        b.addAutor(new Autor("Jack", "London", "S.U.A."));
//        b.addAutor(new Autor("John", "Buchan", "Anglia"));
//
//        b.addCarte(new Carte("Invitatie la vals", 2, 1, "Fictiune", 1936, 15));
//        b.addCarte(new Carte("Cazul Magheru", 2, 2, "Fictiune", 1930, 12));
//        b.addCarte(new Carte("Batranul si marea", 4, 3, "Fictiune", 1952, 5));
//        b.addCarte(new Carte("Old Surehand", 3, 3, "Aventura", 1965, 7));
//        b.addCarte(new Carte("Lupul de stepa", 5, 4, "Filosofie", 1927, 3));
//        b.addCarte(new Carte("Fiesta", 4, 3, "Beletristica", 1926, 2));
//        b.addCarte(new Carte("Lupul de mare", 7, 4, "Aventura", 1904, 3));
//        b.addCarte(new Carte("Colt alb", 7, 4, "Fictiune", 1906, 3));
//        b.addCarte(new Carte("Mantia verde", 8, 3, "Fictiune", 1916, 2));

    }
}